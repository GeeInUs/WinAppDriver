﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Text;
using System.Threading.Tasks;


namespace WinAppDriver
{
   

   
 
namespace PowerShellRunner
    {
        /// <summary>
        /// Contains functionality for executing PowerShell scripts.
        /// </summary>
        public class HostedRunspace
        {
            /// <summary>
            /// The PowerShell runspace pool.
            /// </summary>
          

            /// <summary>
            /// Runs a PowerShell script with parameters and prints the resulting pipeline objects to the console output. 
            /// </summary>
            /// <param name="scriptContents">The script file contents.</param>
            /// <param name="scriptParameters">A dictionary of parameter names and parameter values.</param>
            public async Task RunScript(string scriptContents, Dictionary<string, object> scriptParameters)
            {

                //create Powershell runspace
                Runspace runspace = RunspaceFactory.CreateRunspace();
                runspace.Open();

                RunspaceInvoke runSpaceInvoker = new RunspaceInvoke(runspace);
                runSpaceInvoker.Invoke("Set-ExecutionPolicy Unrestricted");

                
                // create a new hosted PowerShell instance using a custom runspace.
                // wrap in a using statement to ensure resources are cleaned up.

                using (PowerShell ps = PowerShell.Create())
                {
                    // use the runspace created
                    ps.Runspace = runspace;

                   
                    // create a pipeline and feed it the script text
                    Pipeline pipeline = ps.Runspace.CreatePipeline();
                    Command scriptCommand = new Command("", false, true);


                    pipeline.Commands.Add(scriptCommand);

                    Collection<PSObject> cmdResult = pipeline.Invoke();

                    pipeline.Stop();
                    runspace.Close();

                  
                    // print the resulting pipeline objects to the console.
                    Console.WriteLine("----- Pipeline Output below this point -----");
                    foreach (var item in pipelineObjects)
                    {
                        Console.WriteLine(item.BaseObject.ToString());
                    }
                }
            }

            /// <summary>
            /// Handles data-added events for the information stream.
            /// </summary>
            /// <remarks>
            /// Note: Write-Host and Write-Information messages will end up in the information stream.
            /// </remarks>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void Information_DataAdded(object sender, DataAddedEventArgs e)
            {
                var streamObjectsReceived = sender as PSDataCollection<InformationRecord>;
                var currentStreamRecord = streamObjectsReceived[e.Index];

                Console.WriteLine($"InfoStreamEvent: {currentStreamRecord.MessageData}");
            }

            /// <summary>
            /// Handles data-added events for the warning stream.
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void Warning_DataAdded(object sender, DataAddedEventArgs e)
            {
                var streamObjectsReceived = sender as PSDataCollection<WarningRecord>;
                var currentStreamRecord = streamObjectsReceived[e.Index];

                Console.WriteLine($"WarningStreamEvent: {currentStreamRecord.Message}");
            }

            /// <summary>
            /// Handles data-added events for the error stream.
            /// </summary>
            /// <remarks>
            /// Note: Uncaught terminating errors will stop the pipeline completely.
            /// Non-terminating errors will be written to this stream and execution will continue.
            /// </remarks>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void Error_DataAdded(object sender, DataAddedEventArgs e)
            {
                var streamObjectsReceived = sender as PSDataCollection<ErrorRecord>;
                var currentStreamRecord = streamObjectsReceived[e.Index];

                Console.WriteLine($"ErrorStreamEvent: {currentStreamRecord.Exception}");
            }
        }
    }
}
