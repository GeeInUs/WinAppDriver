﻿using System;
using System.Linq;
using OpenQA.Selenium.Appium.Windows;
using System.Diagnostics;
using System.IO;
using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using System.Threading;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Enums;

namespace WinAppDriver.Core
{
    public sealed class ScreenCapture
    {
        public static string ScreenShotFileName { get; set; }

        public static Screenshot currScreenshot { get; set; }

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr GetDesktopWindow();

        [StructLayout(LayoutKind.Sequential)]



        private struct Rect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindowRect(IntPtr hWnd, ref Rect rect);

        private static Image CaptureDesktop()
        {
            return CaptureWindow(GetDesktopWindow());
        }
        private static Bitmap CaptureActiveWindow()
        {
            return CaptureWindow(GetForegroundWindow());
        }



        /// <summary>
        /// Takes a screenshot of the active window
        /// </summary>
        /// <param name="screeshotDir"></param>
        /// <returns></returns>
        public static Tuple<bool, string> TakeActiveWindow(string screeshotDir)
        {
            ScreenShotFileName = screeshotDir + @"\" + DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss_ffffff") + ".jpg";
            try
            {

                Bitmap image = ScreenCapture.CaptureActiveWindow();

                image.Save(ScreenShotFileName);

            }
            catch (Exception) { }
            return new Tuple<bool, string>(File.Exists(ScreenShotFileName), ScreenShotFileName);

        }



        /// <summary>
        /// Takes a screenshot of the desktop 
        /// </summary>
        /// <param name="screeshotDir"></param>
        /// <returns></returns>
        public static Tuple<bool, string> TakeDesktop(string screeshotDir)
        {
            ScreenShotFileName = screeshotDir + @"\" + DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss_ffffff") + ".jpg";
            try
            {

                Image image = ScreenCapture.CaptureDesktop();

                image.Save(ScreenShotFileName);

            }
            catch (Exception) { }

            return new Tuple<bool, string>(File.Exists(ScreenShotFileName), ScreenShotFileName);

        }



        /// <summary>
        ///  Use webdreiver to take a screenshot
        /// </summary>
        /// <param name="screeshotDir"></param>
        /// <param name="WebDriver"></param>
        public static Tuple<bool, string> WebdriverScreenShot(string screeshotDir, IWebDriver WebDriver)
        {
            try
            {
                currScreenshot = null;

                ScreenShotFileName = screeshotDir + @"\" + DateTime.Now.ToString("yyyy_MM_dd_hh_mm_ss_ffffff") + ".jpg";

                currScreenshot = ((ITakesScreenshot)WebDriver).GetScreenshot();

                currScreenshot.SaveAsFile(ScreenShotFileName);

                if (!File.Exists(ScreenShotFileName))
                {
                    using Bitmap bitmap = new Bitmap(GetWindowsScreenWidth(WebDriver), GetWindowsScreenHeight(WebDriver));
                    lock (bitmap)
                    {
                        using (Graphics g = Graphics.FromImage(bitmap))
                        {
                            g.CopyFromScreen(Point.Empty, Point.Empty, bitmap.Size);
                        }
                        bitmap.Save(ScreenShotFileName);



                    }
                }
            }
            catch (Exception) { currScreenshot = null; }
            return new Tuple<bool, string>(File.Exists(ScreenShotFileName), ScreenShotFileName);

        }


        /// <summary>
        /// Gets the window height
        /// <param name="WebDriver"></param>
        /// </summary>
        /// <returns></returns>
        private static int GetWindowsScreenHeight(IWebDriver WebDriver)
        {
            return WebDriver.Manage().Window.Size.Height;
        }

        /// <summary>
        /// Gets the window width
        /// <param name="WebDriver"></param>
        /// </summary>
        /// <returns></returns>
        private static int GetWindowsScreenWidth(IWebDriver WebDriver)
        {
            return WebDriver.Manage().Window.Size.Width;
        }


        private static Bitmap CaptureWindow(IntPtr handle)
        {
            var rect = new Rect();
            GetWindowRect(handle, ref rect);
            var bounds = new Rectangle(rect.Left, rect.Top, rect.Right - rect.Left, rect.Bottom - rect.Top);
            var result = new Bitmap(bounds.Width, bounds.Height);

            using (var graphics = Graphics.FromImage(result))
            {
                graphics.CopyFromScreen(new Point(bounds.Left, bounds.Top), Point.Empty, bounds.Size);
            }

            return result;
        }

    }
    public class BaseWinAppDriver
    {

        protected  WindowsDriver<WindowsElement> BaseAppDriver;
        public struct Application
        {

            public string BaseUrl { get; set; }
            public const string DefaultUrl = "http://127.0.0.1";

            public string BasePort { get; set; }
            public const string DefaultPort = "4723";
          

            public string WinDriverExecutablePath { get; set; }
            public const string DefaultWinDriverExecutablePath = @"C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe";

            public string PlatformName { get; set; }
            public const string DefaultPlatformName = "Windows";
            public string PlatformVersion { get; set; }

            public string DeviceName { get; set; }

            public string AutomationName { get; set; }

            public string App { get; set; }

        }



        private Application AppSettings;


        
        #region Find Application Under Test Elements
        /// <summary>
        /// Find an elememt that contains a text 
        /// </summary>
        /// <param name="elementContainsText"></param>
        /// <returns>The element found</returns>
        public IWebElement FindElementByText(string elementContainsText)
        {
            var elements = BaseAppDriver.FindElements(By.XPath("//*[contains(text(), \"" + elementContainsText + "\") ]"));
            return elements.Count == 1 ? elements[0] : null;
        }



        /// <summary>
        /// Find an elememt by NAME attribute
        /// </summary>
        /// <param name="elementByName"></param>
        /// <returns>The element found</returns>
        public IWebElement FindElementByName(string elementByName)
        {
            var elements = BaseAppDriver.FindElements(By.Name(elementByName));
            return elements.Count == 1 ? elements[0] : null;

        }

        /// <summary>
        /// Find an elememt by ID attribute
        /// </summary>
        /// <param name="elementByID"></param>
        /// <returns>The element found</returns>
        public IWebElement FindElementByID(string elementByID)
        {
            var elements = BaseAppDriver.FindElements(By.Id(elementByID));
            return elements.Count == 1 ? elements[0] : null;

        }

        /// <summary>
        /// Find an elememt by XPATH attribute
        /// </summary>
        /// <param name="elementByXPath"></param>
        /// <returns>The element found</returns>
        public IWebElement FindElementByXPath(string elementByXPath)
        {
            var elements = BaseAppDriver.FindElements(By.XPath(elementByXPath));
            return elements.Count == 1 ? elements[0] : null;

        }


        /// <summary>
        /// Find an elememt by CSS attribute
        /// </summary>
        /// <param name="elementByCSS"></param>
        /// <returns>The element found</returns>
        public IWebElement FindElementByCSS(string elementByCSS)
        {
            var elements = BaseAppDriver.FindElements(By.CssSelector(elementByCSS));
            return elements.Count == 1 ? elements[0] : null;

        }


        /// <summary>
        /// Find an elememt by LINText attribute
        /// </summary>
        /// <param name="elementByLinkText"></param>
        /// <returns>The element found</returns>
        public IWebElement FindElementByLinkText(string elementByLinkText)
        {
            var elements = BaseAppDriver.FindElements(By.LinkText(elementByLinkText));
            return elements.Count == 1 ? elements[0] : null;

        }

        /// <summary>
        /// Find an elememt by CLASSNAME attribute
        /// </summary>
        /// <param name="elementByClassName"></param>
        /// <returns>The element found</returns>
        public IWebElement FindElementByClassName(string elementByClassName)
        {
            var elements = BaseAppDriver.FindElements(By.ClassName(elementByClassName));
            return elements.Count == 1 ? elements[0] : null;

        }

        #endregion

        /// <summary>
        /// The loads an instance of the application 
        /// </summary>
        /// <param name="WinAppConfig">Properties associated with Application to load</param>
        public BaseWinAppDriver(Application WinAppConfig)
        {
            AppSettings = WinAppConfig;
       
            IntializeApplication();

        }


    

        /// <summary>
        ///  Waits for application to be in a ready state
        /// </summary>
        /// <returns></returns>
        private bool IsAppInReadyState()
        {
            
            int i = 0;
            bool StateReady = false;
            while (i < 10 && StateReady == false)
            {
                Thread.Sleep(1000);

                
                IJavaScriptExecutor js = (IJavaScriptExecutor)BaseAppDriver;
                string CurrState = js.ExecuteScript("return document.readyState;").ToString();

                if (CurrState.Equals("interactive") || CurrState.Equals("loading"))
                {
                    Thread.Sleep(1000);
                }

                else if (CurrState.Equals("complete"))
                {
                    StateReady = true;
                    break;
                }

                i++;
            }
            return StateReady;
        }

       

        /// <summary>
        /// Get Application title
        /// </summary>
        public string GetWindowTitle()
        {return BaseAppDriver.Title;}

        /// Navigates back in history
        /// </summary>
        /// <returns></returns>
        public void NavigateBack()
        { BaseAppDriver.Navigate().Back(); }

        /// <summary>
        /// Closes driver instance and every other window associated with it
        /// </summary>
        public void CloseDriver()
        { BaseAppDriver.Quit(); }

        /// Refreshes the app
        /// </summary>
        /// <returns></returns>
        public void Refresh()
        { BaseAppDriver.Navigate().Refresh(); }

        /// <summary>
        /// Maximizes the application under test
        /// </summary>
        public void MaximizeApp()
        {BaseAppDriver.Manage().Window.Maximize(); }


        /// <summary>
        /// Minimizes the application under test
        /// </summary>
        public void MinimizeApp()
        { BaseAppDriver.Manage().Window.Minimize(); }


        #region Window Alert Handling
        /// <summary>
        /// Checks to see if an alert is present
        /// </summary>
        /// <returns></returns>
        public bool IsAlertPresent()
        {
            try
            {
                BaseAppDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        /// <summary>
        /// dismiss or reject  default alert
        /// This simple alert displays some information or warning on the screen.
        /// </summary>
        /// <returns></returns>
        public bool DismissAlert()
        {
            bool CloseAlertOk = false;
            try
            {
                string CurrHandle = GetCurrentWindowHandle();

                if (IsAlertPresent())
                {
                    IAlert alert = BaseAppDriver.SwitchTo().Alert();

                    alert.Dismiss();

                    BaseAppDriver.SwitchTo().Window(CurrHandle);

                    CloseAlertOk = true;
                }

            }
            catch (Exception)
            {
                CloseAlertOk = false;
            }
            return CloseAlertOk;
        }



        /// <summary>
        /// Accept default alert
        /// This simple alert displays some information or warning on the screen.
        /// </summary>
        /// <returns>True if alert clicked ok, false otherwise</returns>
        public bool AcceptAlert()
        {
            bool AcceptAlertOk = false;
            try
            {
                string CurrHandle = GetCurrentWindowHandle();

                if (IsAlertPresent())
                {

                    IAlert alert = BaseAppDriver.SwitchTo().Alert();

                    alert.Accept();

                    BaseAppDriver.SwitchTo().Window(CurrHandle);

                    AcceptAlertOk = true;
                }
            }
            catch (Exception)
            {
                AcceptAlertOk = false;
            }
            return AcceptAlertOk;
        }



        /// <summary>
        /// Gets the current selenium window handle
        /// </summary>
        /// <returns>Returns the current selenium window handle </returns>
        public string GetCurrentWindowHandle()
        {
            ReadOnlyCollection<string> Handles = BaseAppDriver.WindowHandles;
            return Handles[Handles.Count - 1];

        }

        #endregion


        /// <summary>
        /// close default alert based on option provided
        /// </summary>
        /// <param name="text">The name of the text of the alert</param>
        /// <returns>True if alert clicked ok, false otherwise</returns>
        public bool ClickPopupButtonWithText(string text)
        {
            bool FoundTextToClick = false;
            try
            {

                var PopupButtn = BaseAppDriver.FindElements(By.XPath("//*[contains(text(), \"" + text + "\") ]"));

                if (PopupButtn.Count == 1)
                {
                    PopupButtn[0].Click();

                    FoundTextToClick = true;
                }


            }
            catch (Exception)
            {
                FoundTextToClick = false;
            }
            return FoundTextToClick;
        }


   




        /// <summary>
        /// Takes screenshot of browser
        /// </summary>
        /// <param name="CurrTestContext"></param>
        /// <param name="ScreenShotDir"></param>
        public string TakeScreenShot(TestContext CurrTestContext, string ScreenShotDir)
        {
            Tuple<bool, string> SecondTake = null;
            Tuple<bool, string> ThirdTake = null;
            Tuple<bool, string> Result = null;
            try
            {

                if (!Directory.Exists(ScreenShotDir))
                    Directory.CreateDirectory(ScreenShotDir);


                Result = ScreenCapture.WebdriverScreenShot(ScreenShotDir, BaseAppDriver);

                if (Result.Item1 == false)
                    Result = ScreenCapture.TakeActiveWindow(ScreenShotDir);

                else if (SecondTake != null && SecondTake.Item1 == false)
                    Result = ScreenCapture.TakeActiveWindow(ScreenShotDir);

                else if (ThirdTake != null && ThirdTake.Item1 == false)
                    Result = ScreenCapture.TakeActiveWindow(ScreenShotDir);

            }
            catch (Exception) { }

            if (Result.Item1 == true)
                CurrTestContext.AddResultFile(Result.Item2);

            return Result.Item1 == true ? Result.Item2 : null;
        }


        /// <summary>
        /// Set Capability options to launch the Application Under Test
        /// </summary>
        /// <returns></returns>
        private AppiumOptions SetCAppOptions()
        {
            SetDefaultCapParams(); 

             AppiumOptions options = new AppiumOptions();
            
            if (AppSettings.PlatformName != null && AppSettings.PlatformName.Length > 0)
             options.AddAdditionalCapability("platformName", AppSettings.PlatformName);

            if (AppSettings.PlatformVersion != null && AppSettings.PlatformVersion.Length > 0)
                options.AddAdditionalCapability("platformVersion", AppSettings.PlatformVersion);

            if (AppSettings.DeviceName != null && AppSettings.DeviceName.Length > 0)
                options.AddAdditionalCapability("deviceName", AppSettings.DeviceName);

            if (AppSettings.AutomationName != null  && AppSettings.AutomationName.Length > 0)
                options.AddAdditionalCapability("automationName", AppSettings.AutomationName);

            if (AppSettings.App != null && AppSettings.App.Length > 0)
                options.AddAdditionalCapability("app", AppSettings.App);

            return options;
        }

        public AppState GetAppState(string WindowTitle)
        {   return BaseAppDriver.GetAppState(GetAppID(WindowTitle));}


        /// <summary>
        /// Returns appid of the application under test
        /// </summary>
        /// <param name="WindowTitle"></param>
        /// <returns></returns>
        public string GetAppID(string WindowTitle)
        {
            String ID = "";

            using (Process p = new Process())
            {
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = false;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
               
                p.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                p.StartInfo.FileName = @"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe";
                p.StartInfo.Arguments = " get-StartApps | Where-Object {$_.Name -like '*" + WindowTitle + "*'}";
                
                //p.EnableRaisingEvents = true;
                p.Start();
                ID = p.StandardOutput.ReadToEnd();
                p.WaitForExit();
            }

            return ID;
        }


        /// <summary>
        ///  Launches The Application under test
        ///  WinAppDriver is launched in the process also
        private void LaunchApplication()
        {
            try
            {
                var options = SetCAppOptions();
                string AppiumDriverURI = AppSettings.BaseUrl + ":" + AppSettings.BasePort;

                // Starts winAppDriver
                if (!IsWinAppDriverRunning() && AppSettings.WinDriverExecutablePath.Length > 0)
                { Process.Start(AppSettings.WinDriverExecutablePath); }
                
                {

                
                    var ProcessList = Process.GetProcesses(Environment.MachineName).Where(p => p.ProcessName.IndexOf("Zoom", StringComparison.InvariantCultureIgnoreCase) >= 0 && p.Responding == true);
                    options = new AppiumOptions();
                    options.AddAdditionalCapability("appTopLevelWindow", ProcessList.ElementAt(1).MainWindowHandle.ToString("x"));
                    

                }

                BaseAppDriver = new WindowsDriver<WindowsElement>(new Uri(AppiumDriverURI), options);
                BaseAppDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(60);
                MaximizeApp();

            }
            catch (Exception e) {
                Console.WriteLine(e);
            }
        }



        /// <summary>
        ///  Kills a residual process
        /// </summary>
        /// <param name="ProcessName"></param>
        public void StopExecutableProcess(string ProcessName)
        { KillResidueProcess( Process.GetProcessesByName(ProcessName));     }

      

        /// <summary>
        /// waits for a text to appear on a particular page
        /// </summary>
        /// <param name="PageLoadedText">The text value that servers as a visual cue for waiting on </param>
        /// <param name="waitTInMilliseconds">The time to wait for page to load in milliseconds</param>
        /// <returns>True if the page is loaded, false otherwise.</returns>
        public Boolean WaitForTextToAppear(string PageLoadedText, int waitTInMilliseconds)
        {
            Boolean isLoaded = false;
            try
            {

                if (IsAppInReadyState())
                {
                    
                }
            }
            catch (Exception) { }

            return isLoaded;
        }

        /// <summary>
        /// Kills references to existing command console except selenium
        /// </summary>
        public void ReleaseUsedReferences()
        {
            var processes = Process.GetProcesses().Where(p => p.MainWindowTitle.Contains("cmd.exe"));
            foreach (Process p in processes)
            {
                if (p.MainWindowTitle.IndexOf("-jar") >= 0 && p.MainWindowTitle.IndexOf("java") >= 0)
                    p.Kill();
            }

            DisposeResources();
        }

        /// <summary>
        /// Kills references to existing command console except selenium
        /// </summary>
        public void KillHost()
        {
            var processes = Process.GetProcesses().Where(p => p.MainWindowTitle.Contains("cmd.exe"));
            foreach (Process p in processes)
            {
                if (p.MainWindowTitle.IndexOf("TrustedBank") >= 0)
                    p.Kill();
            }


        }




        /// <summary>
        /// checks to see if the Win App Driver is up and running
        /// </summary>
        private bool IsWinAppDriverRunning()
        {return ( Process.GetProcesses().Where(p => p.MainWindowTitle.Contains("WinAppDriver.exe"))).Any() ? true : false; }

        /// <summary>
        /// checks to see if the Application Under Test is up and running
        /// </summary>
        private bool IsWinApplicationRunning()
        {
            return (Process.GetProcesses().Where(p => p.MainWindowTitle.Contains("WinAppDriver.exe")).Any() ? true : false;
        }

        /// <summary>
        /// e
        /// </summary>
        public void DisposeDriver()
        {   DisposeResources(); }


        /// <summary>
        /// Kill selenium driver and residue processes
        /// </summary>
        private void DisposeResources()
        {
            try
            {

                if (BaseAppDriver != null)
                {
                    BaseAppDriver.Quit();

                    BaseAppDriver = null;

                }
            }
            catch (Exception) { }
        }



        /// <summary>
        /// Kills hanging processes from Selenium driver
        /// </summary>
        /// <param name="residue"></param>
        private void KillResidueProcess(Process[] residue)
        {
            foreach (Process p in residue)
            {
                p.Kill();
            }

        }

        /// Navigates forward in history
        /// </summary>
        /// <returns></returns>
        protected void NavigateForward()
        {
            BaseAppDriver.Navigate().Forward();
        }


        /// <summary>
        /// Sets default capabilities associated with the lauching
        /// Application Under Test.
        /// This default capabilities can be overridden at any point
        /// </summary>
        private void SetDefaultCapParams()
        {
            AppSettings.WinDriverExecutablePath = (AppSettings.WinDriverExecutablePath == null || AppSettings.WinDriverExecutablePath.Length <= 1 )
                ? Application.DefaultWinDriverExecutablePath : AppSettings.WinDriverExecutablePath;
            
            AppSettings.BasePort = (AppSettings.BasePort == null || AppSettings.BasePort.Length <= 1 )
                ? Application.DefaultPort : AppSettings.BasePort;
           
            AppSettings.BaseUrl =( AppSettings.BaseUrl == null || AppSettings.BaseUrl.Length <= 1 )
                ? Application.DefaultUrl : AppSettings.BaseUrl;
           
            AppSettings.PlatformName = ( AppSettings.PlatformName == null || AppSettings.PlatformName.Length <= 1 )
                ? Application.DefaultPlatformName : AppSettings.PlatformName;
             
        }

        ///  loads an instance of the windows application
        /// </summary>
        /// <param name="ExecutablePath"></param>
        private void IntializeApplication()
        {
            LaunchApplication();
        }
    }
}

