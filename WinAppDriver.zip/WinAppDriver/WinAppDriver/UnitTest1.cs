﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WinAppDriver.Core;

namespace WinAppDriver
{
    [TestClass]
    public class UnitTest1
    {
        BaseWinAppDriver.Application app;
        [TestMethod]
        public void TestMethod1()
        {
            app.App = @"C:\Users\tishe\AppData\Roaming\Zoom\bin\Zoom.exe";
            app.WinDriverExecutablePath = @"C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe";
            BaseWinAppDriver apasasap = new BaseWinAppDriver(app);

           var a = apasasap.GetAppState("Zoom");


        }
    }
}
